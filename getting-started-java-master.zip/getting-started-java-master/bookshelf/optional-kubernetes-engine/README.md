# Deploy Bookshelf to Google Kubernetes Engine

This optional tutorial will walk you through how to deploy the Bookshelf sample application to
[Google Kubernetes Engine](https://cloud.google.com/kubernetes-engine/). This tutorial is also
applicable to [Kubernetes](http://kubernetes.io/) outside of Google Kubernetes Engine, but may require
additional steps for external load balancing.

Please refer to the
[Tutorial](https://cloud.google.com/java/tutorials/bookshelf-on-kubernetes-engine) for instructions
on how to deploy this sample.
